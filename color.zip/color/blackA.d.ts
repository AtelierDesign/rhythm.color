export declare const blackA: {
    blackA1: string;
    blackA2: string;
    blackA3: string;
    blackA4: string;
    blackA5: string;
    blackA6: string;
    blackA7: string;
    blackA8: string;
    blackA9: string;
    blackA10: string;
    blackA11: string;
    blackA12: string;
};
