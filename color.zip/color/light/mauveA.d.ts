export declare const mauveA: {
    mauveA1: string;
    mauveA2: string;
    mauveA3: string;
    mauveA4: string;
    mauveA5: string;
    mauveA6: string;
    mauveA7: string;
    mauveA8: string;
    mauveA9: string;
    mauveA10: string;
    mauveA11: string;
    mauveA12: string;
};
