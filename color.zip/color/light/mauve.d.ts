export declare const mauve: {
    mauve1: string;
    mauve2: string;
    mauve3: string;
    mauve4: string;
    mauve5: string;
    mauve6: string;
    mauve7: string;
    mauve8: string;
    mauve9: string;
    mauve10: string;
    mauve11: string;
    mauve12: string;
};
