export declare const limeA: {
    limeA1: string;
    limeA2: string;
    limeA3: string;
    limeA4: string;
    limeA5: string;
    limeA6: string;
    limeA7: string;
    limeA8: string;
    limeA9: string;
    limeA10: string;
    limeA11: string;
    limeA12: string;
};
