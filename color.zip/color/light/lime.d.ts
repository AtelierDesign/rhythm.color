export declare const lime: {
    lime1: string;
    lime2: string;
    lime3: string;
    lime4: string;
    lime5: string;
    lime6: string;
    lime7: string;
    lime8: string;
    lime9: string;
    lime10: string;
    lime11: string;
    lime12: string;
};
