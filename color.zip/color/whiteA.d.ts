export declare const whiteA: {
    whiteA1: string;
    whiteA2: string;
    whiteA3: string;
    whiteA4: string;
    whiteA5: string;
    whiteA6: string;
    whiteA7: string;
    whiteA8: string;
    whiteA9: string;
    whiteA10: string;
    whiteA11: string;
    whiteA12: string;
};
